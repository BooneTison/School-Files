package main;

public class MafiaGame {

	
	public static void main(String[] args) {
		StartWindow.openWindow();
	}
}
